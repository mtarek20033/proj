import React from 'react';

function Support() {
  return (
    <div className="support-page">
      <h1>Support</h1>
      <p>Get support for parents and teachers here.</p>
    </div>
  );
}

export default Support;
