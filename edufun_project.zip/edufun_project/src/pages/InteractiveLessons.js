import React from 'react';

function InteractiveLessons() {
  return (
    <div className="interactive-lessons-page">
      <h1>Interactive Lessons</h1>
      <p>Here you can find various interactive lessons for different subjects.</p>
    </div>
  );
}

export default InteractiveLessons;
