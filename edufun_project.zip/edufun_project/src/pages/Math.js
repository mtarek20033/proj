import React from 'react';

function Math() {
  return (
    <div className="math-page">
      <h1>Math Lessons</h1>
      <p>Explore interactive math lessons and challenges.</p>
    </div>
  );
}

export default Math;
