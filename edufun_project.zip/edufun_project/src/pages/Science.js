import React from 'react';

function Science() {
  return (
    <div className="science-page">
      <h1>Science Lessons</h1>
      <p>Discover fun and interactive science lessons.</p>
    </div>
  );
}

export default Science;
